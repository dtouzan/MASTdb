WR4                 02h41m11s +56d43m49s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_OCL132-20261113-2015-13x180s-f85.fits                                                            
48 c Per            04h08m40s +47d42m45s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_48Cper-20261031-2239-17x60s-f85.fits
M 76                01h42m00s +51d34m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_m76-20261107-1738-17x180s-f85.fits
OCL 132             02h37m00s +55d54m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_OCL132-20261113-2015-13x180s-f85.fits
V0488 Sge           19h45m00s +18d22m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_V0488Sge-20260911-2044-18x60s-f85.fits
Gam Cas             00h56m52s +60d43m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_GamCas-20260914-2021-21x30s-f85.fits
V0488 Sge           09h04m00s +18d22m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_V0488Sge-20260915-2012-30x180s-f85.fits
Gam Cas             00h56m52s +60d43m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_GamCas-20260915-2207-13x30s-f85.fits
WR5                 02h52m12s +56d56m07s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET                                                            
C* UV Cam           04h05m53s +61d47m40s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET                                                            
C* V0623 Cas        03h11m25s +57d54m11s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET      
Eps Cas             01h54m23s +63d40m12s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_EpsCas-20261004-1925-19x30s-f85.fits                                                      
Gam Cas             00h56m53s +60d44m00s      1.00  20.00   00    Gray,G,3  UV/IR-CUT SA200                         Spectrum_GamCas_hd5394-20261001-1853-46x15s-f85.fits spectrum_hd5394_20261001_787.fits
Gam Cas             00h56m51s +60d44m01s      1.00  20.00   00    Gray,G,3  UV/IR-CUT SA200                         Spectrum_GamCas_hd5394-20261006-1937-14x15s-f85.fits spectum_hd5394_20261006_817.fits
Del Cas             01h25m48s +60d14m07s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_DelCas-20261005-1946-40x30s-f85.fits
Alp Cas             00h40m30s +56d32m13s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_AlpCas-20261005-2025-20x30s-f85.fits
Bet Cas             00h09m12s +59d08m54s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_BetCas-20261005-2045-20x30s-f85.fits
HD 225136           00h03m51s +66d42m43s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_HD225136-20261006-2103-7x180s-f85.fits
52 Cas              02h02m52s +64d54m04s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_52Cas-20261004-1954-25x60s-f85.fits
HD 12468            02h04m40s +65d06m11s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_52Cas-20261004-1954-25x60s-f85.fits
HD 11946            01h59m38s +64d37m16s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_52Cas-20261004-1954-25x60s-f85.fits