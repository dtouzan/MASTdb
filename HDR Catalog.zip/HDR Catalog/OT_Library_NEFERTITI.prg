WR4                 02h41m11s +56d43m49s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_OCL132-20261113-2015-13x180s-f85.fits                                                            
48 c Per            04h08m40s +47d42m45s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_48Cper-20261031-2239-17x60s-f85.fits
M 76                01h42m00s +51d34m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_m76-20261107-1738-17x180s-f85.fits
OCL 132             02h36m00s +55d54m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum spectrum_OCL132-20261113-2015-13x180s-f85.fits
V0488 Sge           19h45m00s +18d22m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_V0488Sge-20260911-2044-18x60s-f85.fits
Gam Cas             00h56m52s +60d43m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_GamCas-20260914-2021-21x30s-f85.fits
V0488 Sge           09h04m00s +18d22m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_V0488Sge-20260915-2012-30x180s-f85.fits
Gam Cas             00h56m52s +60d43m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_GamCas-20260915-2207-13x30s-f85.fits
WR5                 02h52m12s +56d56m07s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET                                                            
C* UV Cam           04h05m53s +61d47m40s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET                                                            
C* V0623 Cas        03h11m25s +57d54m11s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET                                                            