NGC 7000            20h53m00s +43d56m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7000-20260911-2129-23x180s-f200.fits                                                                                                        
ic 63               00h52m00s +61d06m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         IC63-20260914-2043-30x180s-f200.fits
NGC 7538            23h03m00s +62d09m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7538-20260920-2052-23x180s-f200.fits
NGC 7380            22h47m00s +58d17m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7380-20260921-2005-23x180s-f200.fits
ic 1590             00h54m00s +56d25m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ic1590-20260921-2130-19x180s-f200.fits
NGC 7822            00h03m00s +66d57m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7822-20260922-1941-28x180s-f200.fits       
SN 2026aaiv         22h37m00s +34d23m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         sn2026aaiv-20260922-2152-8x180s-f200.fits      
SH 2-189            02h11m00s +64d02m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         SH2_189-20261001-2046-43x180s-f200.fits  
NGC 7822            00h01m00s +68d06m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7822-20261004-2032-23x180s-f200.fits
NGC 7822            00h01m00s +64d45m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7822-20261005-2107-23x180s-f200.fits       
NGC 7822            00h00m00s +65d53m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7822-20261005-2151-22x180s-f200.fits           
sh 2-188            01h25m00s +58d31m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         sh2-188-20261029-2043-24x180s-f200.fits                                                                                                       
sh 2-173            00h22m00s +61d34m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         sh2-173-20261030-1849-35x180s-f200.fits
375                 01h32m00s +30d35m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT Asteroid                      375-20261031-1912-31x180s-f200.fits
M 33                01h32m00s +30d33m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         m33-20261031-1912-32x180s-f200.fits
NGC 1491            04h09m00s +50d59m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc1491-20261031-2115-23x180s-f200.fits
NGC 1499            03h59m00s +36d14m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc1499-20261102-2119-17x180s-f200.fits
NGC 1624            04h39m00s +50d25m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc1624-20261113-2248-18x180s-f200.fits