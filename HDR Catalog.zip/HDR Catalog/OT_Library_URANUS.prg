NGC 7000            20h53m00s +43d56m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7000-20260911-2129-23x180s-f200.fits                                                                                                        
ic 63               00h52m00s +61d06m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         IC63-20260914-2043-30x180s-f200.fits
NGC 7538            23h03m00s +62d09m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7538-20260920-2052-23x180s-f200.fits
NGC 7380            22h47m00s +58d17m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7380-20260921-2005-23x180s-f200.fits
ic 1590             00h54m00s +56d25m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ic1590-20260921-2130-19x180s-f200.fits
NGC 7822            00h03m00s +66d57m00s      1.00  104.00  00    Green,V,6 UV/IR-CUT field                         ngc7822-20260922-1941-28x180s-f200.fits       
                                                                       